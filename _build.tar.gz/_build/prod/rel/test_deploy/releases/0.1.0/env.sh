#!/bin/sh

# Sets and enables heart (recommended only in daemon mode)
case $RELEASE_COMMAND in
   daemon*)
     HEART_COMMAND="$RELEASE_ROOT/bin/$RELEASE_NAME $RELEASE_COMMAND"
     export HEART_COMMAND
     export ELIXIR_ERL_OPTIONS="-heart"
     ;;
   *)
     ;;
 esac

# Set the release to work across nodes. If using the long name format like
# the one below (my_app@127.0.0.1), you need to also uncomment the
# RELEASE_DISTRIBUTION variable below. Must be "sname", "name" or "none".
# export RELEASE_DISTRIBUTION=name
# export RELEASE_NODE=test_deploy@127.0.0.1


export LC_ALL=en_US.UTF-8

export DATABASE="orcl"
export USER_NAME_DATABASE="hr"
export PASS_DATABASE="oracle"
export HOST_DATABASE="10.255.241.181"
export PORT_DATABASE="1521"
export POOL_SIZE="10"

export SECRET_KEY_BASE="APXip+YM5nhEoFfH6MX6LJgU8QNgpe8EIOPTv80xd6OEqo/K5Zrrkta8exfj7El4"
